exports.config = {
	
  seleniumAddress: 'http://localhost:4444/wd/hub',
  capabilities: {
          'browserName': 'Chrome'
      }, 
  specs: ['test3.js']
}