describe('binding', function() {
 
it('binds',function(){
   browser.get('');
   element(by.model('greet')).sendKeys("World");
   expect(element(by.binding('greet')).getText()).toEqual("Hello World!");
 });
});